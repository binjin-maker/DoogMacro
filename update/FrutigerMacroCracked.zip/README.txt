FrutigerMacroCracked - Setup
============================

1. Download this zip.

2. Rename the .ex_ file to .exe

3. Disable Smart App Control.
   (Windows Security > App & browser control > Smart App Control settings > Off)

   WARNING: This step is required because Windows will not let you use any
   non-paying applications. (That is, paying to big Microsoft.) Downloading and
   running a sketchy app will result in a virus, even if this isn't one. You are
   warned, this setting is mostly in favor of your online safety.

4. Run FrutigerMacroCracked.exe and begin setup.

5. Take a writing test, and reach your automation potential!
